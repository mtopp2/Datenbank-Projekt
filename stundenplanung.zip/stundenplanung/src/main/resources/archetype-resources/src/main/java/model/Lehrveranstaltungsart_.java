package model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-11-23T15:21:37.253+0100")
@StaticMetamodel(Lehrveranstaltungsart.class)
public class Lehrveranstaltungsart_ {
	public static volatile SingularAttribute<Lehrveranstaltungsart, Integer> lvid;
	public static volatile SingularAttribute<Lehrveranstaltungsart, String> lvdauer;
	public static volatile SingularAttribute<Lehrveranstaltungsart, String> lvkurz;
	public static volatile SingularAttribute<Lehrveranstaltungsart, String> lvname;
}
